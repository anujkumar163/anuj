from django.urls import path
from .views import ProfessoreApiView, GradeManagement

urlpatterns = [
	path('Studentdata/', StudentApiView.as_view()),
	path('delstudent/<int:id>/', views.delstudent, name="delstudent"),
    path('updatestudent/<int:id>/', views.updatestudent, name="updatestudent"),
    path('GradeManagementApiView/', views.GradeManagementApiView.as_view()),
    path('delGradeManagement/', views.delGradeManagement, name="delGradeManagement"),
]