from django import forms
from .models import StudentManagement, GradeManagement

class studentForm(forms.ModelForm):
	class Meta():
		model = StudentManagement
		fields = "__all__"

class GradeManagementForm(forms.ModelForm):
	class Meta():
		model = GradeManagement
		fields = "__all__"		