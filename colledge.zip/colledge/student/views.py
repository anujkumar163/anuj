from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import JSONrenderer
from django.http import HttpResponse
from django.http import HttpResponse, JsonResponse
from .models import StudentManagement , GradeManagement
from .serializers import  StudentManagementSerializer, GradeManagementSerializer 
from rest_framework import status 
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.throttling import AnonRateThrottle, UserRateThrottle

# Create your views here.

class studentApiView(APIView):
	throttle_classes = [AnonRateThrottle, UserRateThrottle]
	def get(self, request, pk=None):
		eobjs=StudentManagement.objects.all()
		empJSON = studentSerializer(eobjs, many=True)
		return Response({'data': empJSON.data})

	def post(self, request):
		empser = studentSerializer(data=request.data)
		authentication_class = [BasicAuthentication]
    	permission_classes = [AllowAny]
		print(empser)
		if empser.is_valid():
			empser.save()
			return Response({'msg':'data received'}, status.HTTP_200_OK)
		else:
			return Response(empser.error, status.HTTP_400_BAD_REQUEST)	

	
	def delstudent(self, request, id):
	cobj = StudentManagement.objects.get(id=id)
	cobj.delete()
	

	def updatestudent(request, id):
		if request.method == 'POST':
			name = request.POST['name']
			degree = request.POST['degree']
			DOB = request.POST['DOB']
			course = request.POST['course']
			professore = request.POST['professore']
			semester = request.POST['semester']

			cobj = StudentManagement.objects.filter(id=id)#QuerySet
			cobj.update(name=name, degree=degree, DOB=DOB, course=course, professore=professore, semester=semester )
			authentication_class = [BasicAuthentication]
    		permission_classes = [AllowAny]

		else:	
			c = StudentManagement.objects.get(id=id)
			return render(request, "studentupdate.html",{'data': c})	


class GradeManagementApiView(APIView):
	def get(self, request, pk=None):
		eobjs=GradeManagement.objects.all()
		empJSON = GradeManagementSerializer(eobjs, many=True)
		return Response({'data': empJSON.data})

	def post(self, request):
		empser = GradeManagementSerializer(data=request.data)
		print(empser)
		if empser.is_valid():
			empser.save()
			return Response({'msg':'data received'}, status.HTTP_200_OK)
		else:
			return Response(empser.error, status.HTTP_400_BAD_REQUEST)	

	
	def delGradeManagement(self, request, id):
	cobj = GradeManagement.objects.get(id=id)
	cobj.delete()
	authentication_class = [BasicAuthentication]
    permission_classes = [AllowAny]

