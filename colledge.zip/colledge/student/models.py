from django.db import models

# Create your models here.
class StudentManagement(models.Model):
	name = models.CharField(max_length=100)
	degree = models.CharField(max_length=100)
	DOB = models.IntegerField()
	course = models.ForeignKey(Course,on_delete=models.CASCADE)
    professore = models.ForeignKey(Professore,on_delete=models.CASCADE)
    semester = models.ForeignKey(Course,on_delete=models.CASCADE)

class GradeManagement(models.Model):
    course= models.ForeignKey(Course,on_delete=models.CASCADE)
    marks = models.FloatField(default=0)
    internal_marks = models.FloatField(default=0)
    grades = models.CharField(max_length=299)
    status = models.CharField(max_length=288)
    total_marks = models.FloatField(default=0)

    def set_grades_and_status(sender,instance,**kwargs):
        if instance.marks >= 80 and instance.marks <= 100:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 80 and instance.total_marks <= 100:
                instance.grade = "A"

        elif instance.marks >= 75 and instance.marks <= 79:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 75 and instance.total_marks <= 79:
                instance.grade = "A-"

        elif instance.marks >= 70 and instance.marks <= 74:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 80 and instance.total_marks <= 100:
                instance.grade = "B+"

        elif instance.marks >= 65 and instance.marks <= 69:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 65 and instance.total_marks <= 69:
                instance.grade = "B"

        elif instance.marks >= 60 and instance.marks <= 64:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 60 and instance.total_marks <= 64:
                instance.grade = "B-"

        elif instance.marks >= 55 and instance.marks <= 59:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 55 and instance.total_marks <= 59:
                instance.grade = "C+"

        elif instance.marks >= 50 and instance.marks <= 54:
            instance.status = 'Pass'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 50 and instance.total_marks <= 54:
                instance.grade = "C"

        elif instance.marks >= 40 and instance.marks <= 49:
            instance.status = 'Fail'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 40 and instance.total_marks <= 49:
                instance.grade = "C-"

        elif instance.marks >= 35 and instance.marks <= 39:
            instance.status = 'Fail'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 35 and instance.total_marks <= 39:
                instance.grade = "D+"

        elif instance.marks >= 33 and instance.marks <= 34:
            instance.status = 'Fail'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 33 and instance.total_marks <= 34:
                instance.grade = "D"

        elif instance.marks >= 31 and instance.marks <= 32:
            instance.status = 'Fail'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 31 and instance.total_marks <= 32:
                instance.grade = "D-"

        elif instance.marks >= 0 and instance.marks <= 30:
            instance.status = 'Fail'
            instance.total_marks = float(instance.marks+instance.internal_marks)
            if instance.total_marks >= 0 and instance.total_marks <= 30:
                instance.grade = "F"

        else:
            instance.grades = 'NA'
            instance.status = 'NA'
pre_save.connect(GradeManagement.set_grades_and_status,sender=GradeManagement)        