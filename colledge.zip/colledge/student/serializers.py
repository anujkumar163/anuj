from rest_framework import serializers
from .models import StudentManagement,  GradeManagement

class StudentSerializer(serializers.ModelSerializer):
	class meta():
		model = StudentManagement
		fields = '__all__'from
class StudentManagementSerializer(serializers.ModelSerializer):
	class meta():
		model = GradeManagement	
		firlds = '__all__'from	