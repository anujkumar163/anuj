from django.db import models

# Create your models here.
class Course(models.Model):
	course = models.CharField(max_length=100)
	semester = models.IntegerField()
	professore = models.CharField(max_length=200)
	
# Create your models here.
