from rest_framework import serializers
from .models import course

class CourseSerializer(serializers.ModelSerializer):
	class meta():
		model = Course
		fields = '__all__'from