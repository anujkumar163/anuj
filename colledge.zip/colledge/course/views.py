from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import JSONrenderer
from django.http import HttpResponse
from django.http import HttpResponse, JsonResponse
from .models import Course 
from .serializers import  CourseSerializer 
from rest_framework import status 
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny

# Create your views here.

class CourseApiView(APIView):
	def get(self, request, pk=None):
		eobjs=Course.objects.all()
		empJSON = CourseSerializer(eobjs, many=True)
		return Response({'data': empJSON.data})

	def post(self, request):
		empser = CourseSerializer(data=request.data)
		authentication_class = [BasicAuthentication]
    	permission_classes = [IsAuthenticated]
		print(empser)
		if empser.is_valid():
			empser.save()
			return Response({'msg':'data received'}, status.HTTP_200_OK)
		else:
			return Response(empser.error, status.HTTP_400_BAD_REQUEST)	

	
	def delcourse(self, request, id):
	cobj = Course.objects.get(id=id)
	cobj.delete()
	authentication_class = [BasicAuthentication]
    permission_classes = [IsAuthenticated]
	

	def updatecourse(request, id):
		if request.method == 'POST':
			course = request.POST['course']
			semester = request.POST['semester']
			professore = request.POST['professore']
			p = request.POST['pin']
			m = request.POST['mob']

			cobj = Course.objects.filter(id=id)#QuerySet
			cobj.update(course=course, semester=semester, professore=professore)
			authentication_class = [BasicAuthentication]
    		permission_classes = [IsAuthenticated]

		else:	
			c = Course.objects.get(id=id)
			return render(request, "updatecourse.html",{'data': c})	