from django.urls import path
from .views import courseApiView

urlpatterns = [
	path('Coursedata/', CourseApiView.as_view()),
	path('delcourse/<int:id>/', views.delcourse, name="deletecourse"),
    path('updatecourse/<int:id>/', views.updatecourse, name="updatecourse"),
]
