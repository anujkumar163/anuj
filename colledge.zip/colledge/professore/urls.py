from django.urls import path
from .views import professoreApiView

urlpatterns = [
	path('Professoredata/', ProfessoreApiView.as_view()),
	path('delprofessore/<int:id>/', views.delprofessore, name="deleteprofessore"),
    path('updateprofessore/<int:id>/', views.updateprofessore, name="updateprofessore"),
]