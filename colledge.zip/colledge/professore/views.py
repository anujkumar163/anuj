from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import JSONrenderer
from django.http import HttpResponse
from django.http import HttpResponse, JsonResponse
from .models import Professore 
from .serializers import  ProfessoreSerializer 
from rest_framework import status 
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny

# Create your views here.

class ProfessoreApiView(APIView):
	def get(self, request, pk=None):
		eobjs= Professore.objects.all()
		empJSON = ProfessoreSerializer(eobjs, many=True)
		return Response({'data': empJSON.data})

	def post(self, request):
		empser = ProfessoreSerializer(data=request.data)
		authentication_class = [BasicAuthentication]
    	permission_classes = [IsAuthenticated]
		print(empser)
		if empser.is_valid():
			empser.save()
			return Response({'msg':'data received'}, status.HTTP_200_OK)
		else:
			return Response(empser.error, status.HTTP_400_BAD_REQUEST)	

	
	def delprofessore(self, request, id):
	cobj = Professore.objects.get(id=id)
	cobj.delete()
	authentication_class = [BasicAuthentication]
    permission_classes = [IsAuthenticated]
	

	def updateprofessore(request, id):
		if request.method == 'POST':
			name = request.POST['name']
			course = request.POST['course']
			semester = request.POST['semester']

			cobj = Professore.objects.filter(id=id)#QuerySet
			cobj.update(name=name, course=course, semestr=semester)
			authentication_class = [BasicAuthentication]
    		permission_classes = [IsAuthenticated]

		else:	
			c = Professore.objects.get(id=id)
			return render(request, "updateprofessore.html",{'data': c})	
