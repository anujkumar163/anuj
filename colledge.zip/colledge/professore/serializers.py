from rest_framework import serializers
from .models import Professore

class ProfessoreSerializer(serializers.ModelSerializer):
	class meta():
		model = Professore
		fields = '__all__'from