from django.apps import AppConfig


class ProfessoreConfig(AppConfig):
    name = 'professore'
